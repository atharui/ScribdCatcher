const { chromium } = require('playwright-core');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { createInterface } = require('node:readline/promises');

async function convert(browser, url, output, suppliedCount = 0) {
  const context = await browser.newContext({ acceptDownloads: true, locale: 'en-US' });
  const tmp = path.join(path.dirname(output), randomUUID() + '.part.pdf');
  let done, fail, busy = false, timer;
  const result = new Promise((resolve, reject) => { done = resolve; fail = reject; });
  result.catch(() => {});
  async function receive(write) {
    if (busy) return;
    busy = true;
    try { await write(); done(); } catch (e) { fail(e); }
  }
  try {
    await context.exposeBinding('sendPrintRequestToLocalApp', async ({page, frame}) => {
      if (page.mainFrame() !== frame) {
        fail(new Error('الموقع يطبع إطارًا فرعيًا. تعذّر تحديد صفحات المستند بأمان.'));
        return;
      }
      await receive(async () => {
        await page.evaluate(async () => {
          await document.fonts.ready;
          await Promise.all([...document.images].filter(i => i.getClientRects().length)
            .map(i => i.decode()));
        });
        await page.pdf({path:tmp, printBackground:true, preferCSSPageSize:true});
      });
    });
    await context.addInitScript(() => {
      window.print = () => { void window.sendPrintRequestToLocalApp(); };
    });
    context.on('page', p => p.on('download', d => receive(() => d.saveAs(tmp))));
    const page = await context.newPage();
    let response = await page.goto(url, {waitUntil:'domcontentloaded'}).catch(e => {
      if (!/Download is starting|ERR_ABORTED/.test(e.message)) throw e;
    });
    if (response && !response.ok()) throw new Error('HTTP ' + response.status());
    let count = suppliedCount;
    const current = new URL(page.url());
    const docId = /^\/(?:document|doc|presentation)\/(\d+)(?:\/|$)/.exec(current.pathname)?.[1];
    if(response && docId && /^(www\.)?scribd\.com$/.test(current.host) && !busy) {
      console.log('أبحث عن رابط التضمين للمستند '+docId+'…');
      const target = await require('./ScribdCatcher.embed.cjs').discover(page,docId);
      if(target) {
        console.log('وجدت العارض، جاري فتحه وتجهيز الصفحات…');
        response = await page.goto(target,{waitUntil:'domcontentloaded'});
        if(!response?.ok() || !require('./ScribdCatcher.embed.cjs').sameDocument(page.url(),docId)) {
          throw Error('فتح رابط التضمين لم يؤدّ إلى عارض المستند.');
        }
      } else {
        console.log('لم يظهر رابط تضمين مطابق. سأحاول التنزيل أو الطباعة من صفحة المستند…');
        if(page.url()!==current.href) await page.goto(current.href,{waitUntil:'domcontentloaded'});
        const close = page.getByRole('button',{name:/^close dialog$|^إغلاق$/i}).first();
        if(await close.isVisible()) await close.click();
      }
    }
    if (response && /application\/pdf/i.test(response.headers()['content-type'] || '')) {
      await receive(async () => fs.writeFile(tmp, await response.body()));
    } else if (response && /(?:^|\.)scribd\.com$/.test(new URL(page.url()).hostname) && /^\/embeds\/\d+\/content\/?$/.test(new URL(page.url()).pathname)) {
      await receive(async () => { count = await require('./ScribdCatcher.visible.cjs').captureVisible(page,tmp); });
    } else if (response && !busy) {
      const text = await page.locator('body').innerText();
      const match = text.match(/\b([\d,]+)\s+pages\b/i);
      if (!count && match) count = Number(match[1].replaceAll(',',''));
      const print = page.getByRole('button',{name:/^print$|^طباعة$/i}).first();
      const download = page.getByRole('button',{name:/^download$|^تنزيل$/i}).first();
      if (await print.isVisible()) {
        await print.click();
        const next = page.getByRole('button',{name:/^download and print$/i}).first();
        if (await next.isVisible({timeout:1000})) await next.click();
      } else if (await download.isVisible()) await download.click();
    }
    if (!busy) console.log('بانتظار تسليم الملف أو أمر الطباعة من الصفحة المفتوحة. يمكنك استخدام عناصر العارض.');
    await Promise.race([result, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('انتهى الانتظار دون استلام مستند من العارض.')), 120000);
    })]);
    const check = spawnSync(process.env.PDF_PYTHON || 'python',
      [path.join(__dirname,'ScribdCatcher.check.py'), tmp, String(count)], {encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8'}});
    if (check.error || check.status !== 0) throw new Error(check.stderr || String(check.error));
    await fs.copyFile(tmp,output,require('node:fs').constants.COPYFILE_EXCL);
    console.log(check.stdout.trim(), output);
  } finally {
    clearTimeout(timer);
    await context.close();
    await fs.rm(tmp,{force:true});
  }
}
module.exports = {convert};
if (require.main === module) (async () => {
  const rl = createInterface({input:process.stdin,output:process.stdout});
  let url;
  try { url = new URL(process.argv[2] || await rl.question('رابط المستند: ')); }
  finally { rl.close(); }
  if (url.protocol !== 'https:') throw new Error('أدخل رابط HTTPS');
  const dir = path.join(os.homedir(),'Downloads','ScribdCatcher');
  await fs.mkdir(dir,{recursive:true});
  console.log('جاري فتح كروم…');
  const b = await chromium.launch({channel:'chrome',headless:false});
  try {
    const name = url.pathname.split('/').filter(Boolean).pop()?.replace(/[^\p{L}\p{N} _-]/gu,'_').slice(0,65) || 'Document';
    await convert(b,url.href,path.join(dir,name+'-'+Date.now()+'.pdf'));
  } finally { await b.close(); }
})().catch(e => {console.error(e.message);process.exitCode=1;});
