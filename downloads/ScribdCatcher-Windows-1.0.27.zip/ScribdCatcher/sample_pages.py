import sys
from pathlib import Path

import fitz

with fitz.open(sys.argv[1]) as document:
    for number, page in enumerate(document, start=1):
        scale = min(2, 1200 / page.rect.width)
        image = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
        image.save(Path(sys.argv[2]) / f'preview-{number}.png')
