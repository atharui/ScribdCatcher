const path = require('node:path');

// Produce an inert, local representation of the rendered page. No site scripts
// or interactive controls are transferred into the export document.
function serializePage(root, mode) {
  const rect=root.getBoundingClientRect();
  const width=rect.width, height=rect.height;
  const segmenter=mode==='svg' ? new Intl.Segmenter(undefined,{granularity:'grapheme'}) : null;
  const metricsContext=mode==='svg' ? document.createElement('canvas').getContext('2d') : null;
  const svgNS='http://www.w3.org/2000/svg';
  const svg=document.createElementNS(svgNS,'svg');
  svg.setAttribute('xmlns',svgNS);
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  function shape(tag, attrs) {
    const node=document.createElementNS(svgNS,tag);
    for(const [key,value] of Object.entries(attrs)) node.setAttribute(key,value);
    svg.append(node);
    return node;
  }
  const relative = box=>({x:box.left-rect.left,y:box.top-rect.top,width:box.width,height:box.height});
  function imageURL(el) {
    if(el.tagName==='CANVAS') return el.toDataURL('image/png');
    if(!el.complete || !el.naturalWidth) throw Error('صورة لم يكتمل تحميلها');
    return el.currentSrc || el.src;
  }
  const safeURL=url=>/^(https?:|data:image\/)/i.test(url);
  function walk(el) {
    const style=getComputedStyle(el), box=el.getBoundingClientRect();
    if(/^(SCRIPT|STYLE|LINK|IFRAME|OBJECT|INPUT|BUTTON|NOSCRIPT)$/.test(el.tagName) ||
       style.display==='none' || style.visibility==='hidden' || Number(style.opacity)===0) return null;
    const pos=relative(box);
    const img=el.tagName==='IMG' || el.tagName==='CANVAS';
    if(mode==='svg') {
      if(style.backgroundImage!=='none' || (el.tagName.toLowerCase()==='svg'))
        throw Error('الصفحة تحتوي رسماً أو خلفية لا يدعمها محوّل SVG الحالي');
      if(style.backgroundColor!=='rgba(0, 0, 0, 0)' && pos.width && pos.height)
        shape('rect',{...pos,fill:style.backgroundColor});
      if(img) {
        const src=imageURL(el);
        if(!safeURL(src)) throw Error('تعذرت قراءة صورة الصفحة');
        shape('image',{...pos,href:src,preserveAspectRatio:'none'});
      }
      for(const child of el.childNodes) {
        if(child.nodeType===1) { walk(child); continue; }
        if(child.nodeType!==3 || !child.textContent.trim()) continue;
        const value=child.textContent;
        const range=document.createRange();
        const offsets=Array.from(segmenter.segment(value),part=>part.index);
        offsets.push(value.length);
        metricsContext.font=style.fontStyle+' '+style.fontWeight+' '+style.fontSize+' '+style.fontFamily;
        const metrics=metricsContext.measureText('Hg');
        const ascent=metrics.fontBoundingBoxAscent;
        const fontHeight=ascent+metrics.fontBoundingBoxDescent;
        // A DOM range is measured after ancestor scaling. CSS fontSize is not.
        // Map the font metrics into the actual on-screen line box.
        function draw(first,last,box) {
          const r=relative(box);
          const text=value.slice(offsets[first],offsets[last]);
          if(!text.trim() || !r.width || !r.height) return;
          const scale=fontHeight>0 ? r.height/fontHeight : 1;
          const rtl=style.direction==='rtl';
          const txt=shape('text',{x:rtl?r.x+r.width:r.x,
            y:r.y+(fontHeight>0?ascent*scale:r.height*0.8),fill:style.color,
            direction:style.direction,'font-family':style.fontFamily,
            'font-size':parseFloat(style.fontSize)*scale,'font-weight':style.fontWeight,
            'font-style':style.fontStyle,textLength:r.width,lengthAdjust:'spacingAndGlyphs'});
          txt.style.whiteSpace=style.whiteSpace.startsWith('pre')?'pre':'normal';
          txt.textContent=text;
        }
        // Keep words and their spaces in the same SVG text run whenever they
        // occupy one browser fragment. Split only at actual visual breaks.
        let first=0;
        while(first<offsets.length-1) {
          range.setStart(child,offsets[first]);
          let low=first+1, high=offsets.length-1;
          while(low<high) {
            const mid=Math.ceil((low+high)/2);
            range.setEnd(child,offsets[mid]);
            if(range.getClientRects().length<=1) low=mid;
            else high=mid-1;
          }
          range.setEnd(child,offsets[low]);
          draw(first,low,range.getBoundingClientRect());
          first=low;
        }
      }
      return;
    }
    if(el.namespaceURI===svgNS) throw Error('تحتوي الصفحة على رسم SVG داخلي غير مدعوم في تصدير الطباعة');
    const tag=img?'img':/^(DIV|SPAN|P|ARTICLE|SECTION|H[1-6]|B|I|STRONG|EM|BR|TABLE|TBODY|TR|TD|TH|UL|OL|LI|SUP|SUB)$/.test(el.tagName)?el.tagName:'div';
    const clone=document.createElement(tag);
    for(const prop of style) clone.style.setProperty(prop,style.getPropertyValue(prop));
    if(img) {
      const src=imageURL(el);
      if(!safeURL(src)) throw Error('تعذرت قراءة صورة الصفحة');
      clone.setAttribute('src',src);
    } else for(const child of el.childNodes) {
      if(child.nodeType===3) clone.append(child.cloneNode());
      else if(child.nodeType===1) {const c=walk(child);if(c)clone.append(c);}
    }
    return clone;
  }
  const copy=walk(root);
  if(mode==='svg') return {width,height,markup:svg.outerHTML};
  if(!copy) throw Error('تعذرت قراءة الورقة');
  Object.assign(copy.style,{position:'relative',inset:'auto',margin:'0',transform:'none'});
  return {width,height,markup:copy.outerHTML};
}

async function exportSheet(el,render,dir,n,mode) {
  await el.scrollIntoViewIfNeeded();
  await el.evaluate(async node=>{
    await document.fonts.ready;
    await Promise.all([...node.querySelectorAll('img')].filter(im=>im.getClientRects().length).map(im=>im.decode()));
  },undefined,{timeout:15000});
  const {width,height,markup}=await el.evaluate(serializePage,mode);
  await render.setViewportSize({width:Math.ceil(width),height:Math.ceil(height)});
  await render.setContent(`<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: https: http:; style-src 'unsafe-inline'"><style>@page{size:${width}px ${height}px;margin:0}html,body{margin:0;padding:0}body{width:${width}px;height:${height}px;overflow:hidden;-webkit-print-color-adjust:exact}body>svg{width:100%;height:100%}</style>${markup}`,{waitUntil:'load',timeout:20000});
  await render.evaluate(async()=>{
    for(const el of document.querySelectorAll('svg image')) {
      const img=new Image();img.src=el.getAttribute('href');await img.decode();
    }
    await document.fonts.ready;
    await Promise.all([...document.images].map(img=>img.decode()));
  });
  await render.emulateMedia({media:'screen'});
  await render.pdf({path:path.join(dir,'sheet-'+n+'.pdf'),preferCSSPageSize:true,printBackground:true});
}
module.exports={exportSheet};
