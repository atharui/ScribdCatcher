﻿$ErrorActionPreference = 'Stop'
try {
    Add-Type -Path (Join-Path $PSScriptRoot 'QueueLifetime.cs')
    [QueueLifetime]::Join($env:SC_QUEUE_JOB)
    Set-Location -LiteralPath $PSScriptRoot
    $uv = (Get-Command uv.exe -ErrorAction Stop).Source
    $log = Join-Path $env:TEMP ('ScribdCatcher-Queue-' + $PID + '.log')
    $ErrorActionPreference = 'Continue'
    & $uv run --no-project --python 3.12 --with 'PySide6>=6.7,<7' --with 'PyMuPDF>=1.25,<2' python queue_window.py *> $log
    if ($LASTEXITCODE -ne 0) { throw ((Get-Content -LiteralPath $log -Tail 12) -join [Environment]::NewLine) }
    Remove-Item -LiteralPath $log -ErrorAction SilentlyContinue
} catch {
    if ($env:SC_QUEUE_OWNER -and !(Get-Process -Id ([int]$env:SC_QUEUE_OWNER) -ErrorAction SilentlyContinue)) {exit 1}
    Add-Type -AssemblyName System.Windows.Forms
    [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'ScribdCatcher')
}
