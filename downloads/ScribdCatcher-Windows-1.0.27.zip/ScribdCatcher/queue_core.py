import os
import re
import sqlite3
import threading
import uuid
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen
from datetime import datetime

import pymupdf as pdf


def connect(base):
    db = sqlite3.connect(base / 'queue.sqlite', timeout=20)
    db.row_factory = sqlite3.Row
    db.execute("""CREATE TABLE IF NOT EXISTS jobs(
        id TEXT PRIMARY KEY, source TEXT, local TEXT, folder TEXT, pages TEXT,
        scale INTEGER, state TEXT, title TEXT, total INTEGER DEFAULT 0,
        done INTEGER DEFAULT 0, goal INTEGER DEFAULT 0, output TEXT DEFAULT '',
        finished TEXT DEFAULT '', size INTEGER DEFAULT 0, error TEXT DEFAULT '')""")
    return db


def pages_for(spec, count):
    if not spec.strip():
        return list(range(count))
    chosen = set()
    for item in spec.replace('،', ',').split(','):
        match = re.fullmatch(r'\s*(\d+)\s*(?:-\s*(\d+)\s*)?', item)
        if not match:
            raise ValueError('Invalid page range / نطاق الصفحات غير صحيح')
        first, last = int(match[1]), int(match[2] or match[1])
        if not 1 <= first <= last <= count:
            raise ValueError(f'Page range / نطاق الصفحات: 1–{count}')
        chosen.update(range(first - 1, last))
    return sorted(chosen)


def is_viewer(source):
    host = (urlsplit(source).hostname or '').lower()
    return host == 'scribd.com' or host.endswith('.scribd.com')


def add(db, source, folder, spec, scale):
    path = Path(source)
    local = path.is_file() if not source.lower().startswith(('https://','http://')) else False
    if not local and (urlsplit(source).scheme != 'https' or not urlsplit(source).hostname):
        raise ValueError('Expected HTTPS or a PDF file / أدخل رابط HTTPS أو ملف PDF')
    job = uuid.uuid4().hex
    db.execute('INSERT INTO jobs(id,source,local,folder,pages,scale,state,title) VALUES(?,?,?,?,?,?,?,?)',
               (job, source, str(path.resolve()) if local else '', str(folder), spec, scale,
                'attach' if not local and is_viewer(source) else 'ready', source))
    return job


def update(db, job, **values):
    with db:
        db.execute('UPDATE jobs SET '+','.join(k+'=?' for k in values)+' WHERE id=?',
                   (*values.values(),job))


def check(stop):
    if stop.is_set():
        raise InterruptedError()


def source_copy(row, work, stop):
    cached = work / 'input.pdf'
    if cached.exists():
        return cached
    if not row['local'] and is_viewer(row['source']):
        raise ValueError('Attach the downloaded PDF / اربط ملف PDF بعد تنزيله')
    stream = open(row['local'],'rb') if row['local'] else urlopen(row['source'], timeout=20)
    tmp = work / 'input.tmp'
    try:
        with stream, tmp.open('wb') as out:
            while True:
                check(stop)
                chunk = stream.read(262144)
                if not chunk:
                    break
                out.write(chunk)
        with pdf.open(tmp) as doc:
            if not doc.is_pdf or doc.needs_pass or not len(doc):
                raise ValueError('A readable PDF is required / يلزم ملف PDF قابل للقراءة')
        tmp.replace(cached)
    finally:
        tmp.unlink(missing_ok=True)
    return cached


def pixels(page, scale):
    factor = scale or 1
    if page.rect.width * page.rect.height * factor**2 > 32_000_000:
        raise ValueError('Choose a lower resolution / اختر دقة أقل لهذه الصفحة')
    return page.get_pixmap(matrix=pdf.Matrix(factor,factor),alpha=False)


def run_job(base, job, stop, preview=False):
    db = connect(base)
    try:
        row = db.execute('SELECT * FROM jobs WHERE id=?',(job,)).fetchone()
        work = base / job
        work.mkdir(exist_ok=True)
        src = source_copy(row,work,stop)
        with pdf.open(src) as doc:
            title = (doc.metadata or {}).get('title') or Path(urlsplit(row['source']).path).stem or 'Document'
            indices = pages_for(row['pages'],len(doc))
            update(db,job,title=title,total=len(doc),goal=len(indices))
            if preview:
                return title,len(doc),indices[0]+1,pixels(doc[indices[0]],row['scale']).tobytes('png')
            update(db,job,state='running',error='')
            for pos,index in enumerate(indices):
                check(stop)
                dst = work / f'{pos}.pdf'
                if not dst.exists():
                    with pdf.open() as one:
                        if row['scale']:
                            page = doc[index]
                            one.new_page(width=page.rect.width,height=page.rect.height).insert_image(
                                page.rect,pixmap=pixels(page,row['scale']))
                        else:
                            one.insert_pdf(doc,from_page=index,to_page=index)
                        tmp = work / 'page.tmp'
                        one.save(tmp,deflate=True)
                    tmp.replace(dst)
                update(db,job,done=pos+1)
        check(stop)
        folder = Path(row['folder'])
        folder.mkdir(parents=True,exist_ok=True)
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_',title)[:100].strip(' .') or 'Document'
        out = folder / f'{name} - {job[:8]}.pdf'
        tmp = folder / ('.'+job+'.tmp')
        try:
            with pdf.open() as result:
                for pos in range(len(indices)):
                    check(stop)
                    with pdf.open(work/f'{pos}.pdf') as one:
                        result.insert_pdf(one)
                result.save(tmp,garbage=3,deflate=True)
            check(stop)
            os.replace(tmp,out)
        finally:
            tmp.unlink(missing_ok=True)
        update(db,job,state='done',output=str(out),size=out.stat().st_size,
               finished=datetime.now().strftime('%Y-%m-%d %H:%M'))
        for p in work.glob('*.pdf'):
            if p.name != 'input.pdf':
                p.unlink(missing_ok=True)
    finally:
        db.close()


# A pasted Scribd slug may end immediately before the next document URL.
# Preserve embedded callback URLs in query strings of unrelated links.
DOC_START = re.compile(r'https://(?:www\.|[a-z]{2}\.)?scribd\.com/(?:(?:document|doc|embeds|presentation|read)/)\d+', re.I)
def pasted_links(text):
    result=[]
    for token in text.split():
        starts=list(DOC_START.finditer(token))
        if len(starts)>1 and starts[0].start()==0 and '?' not in token[:starts[1].start()]:
            offsets=[m.start() for m in starts]+[len(token)]
            result.extend(token[a:b] for a,b in zip(offsets,offsets[1:]))
        else:
            result.append(token)
    return list(dict.fromkeys(result))


def repair_combined_rows(db):
    with db:
        rows=list(db.execute("SELECT * FROM jobs WHERE state='attach' AND local=''"))
        for row in rows:
            links=pasted_links(row['source'])
            if len(links)<2 or not all(DOC_START.match(v) for v in links):continue
            db.execute('UPDATE jobs SET source=?,title=? WHERE id=?',(links[0],links[0],row['id']))
            for link in links[1:]:
                add(db,link,row['folder'],row['pages'],row['scale'])


def document_label(source):
    from urllib.parse import unquote
    m=DOC_START.match(source)
    if not m:return source
    slug=unquote(urlsplit(source).path.rstrip('/').rsplit('/',1)[-1])
    return slug.replace('-',' ') if slug and not slug.isdigit() else m[0].rsplit('/',1)[-1]
