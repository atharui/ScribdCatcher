const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const {spawnSync} = require('node:child_process');

function runAssembler(dir,action,number) {
  return spawnSync(process.env.PDF_PYTHON || 'python',[path.join(__dirname,'ScribdCatcher.assemble.py'),dir,action,String(number)],{encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8'}});
}

async function captureVisible(page, output, mode="capture") {
  const pixelRatio = await page.evaluate(() => window.devicePixelRatio);
  const jump = page.getByRole('textbox', {name:/jump to page/i});
  await jump.waitFor({timeout:15000});
  const text = await page.locator('body').innerText();
  const totals = [...text.matchAll(/(?:^|\n)\s*\/\s*(\d+)\s*(?=\n|$)/g)];
  const available = Number(totals.at(-1)?.[1]);
  if (!Number.isInteger(available) || available < 1) throw Error('تعذرت قراءة عدد صفحات العارض');
  const total = process.env.SC_SAMPLE === "3" ? Math.min(available, 3) : available;
  const dir = await fs.mkdtemp(path.join(os.tmpdir(),'reader-'));
  const render=mode==='capture'?null:await page.context().newPage();
  try {
    for (let n=1;n<=total;n++) {
      while (process.env.SC_PAUSE_FILE && require('node:fs').existsSync(process.env.SC_PAUSE_FILE)) {
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      await jump.fill(String(n)); await jump.press('Enter');
      const candidates = page.locator(`#outer_page_${n}, #pageNum${n}, .outer_page[data-page-num="${n}"], .page[data-page-number="${n}"]`);
      const ordered = page.locator('.outer_page');
      const el = await candidates.count() ? candidates.first() :
        await ordered.count() === available ? ordered.nth(n-1) : candidates.first();
      await el.waitFor({timeout:10000});
      const size = await el.boundingBox();
      if (!size || size.width < 120 || size.height < 160) throw Error('تعذرت قراءة حدود الصفحة '+n);
      const viewport=page.viewportSize();
      if(viewport && size.height+180>viewport.height && viewport.height<2400) {
        await page.setViewportSize({width:viewport.width,height:Math.min(2400,Math.ceil(size.height)+180)});
      }
      let fallback='';
      for (let attempt=1; attempt<=3; attempt++) {
        try {
          const sheet = path.join(dir,'sheet-'+n+'.pdf');
          if(render && !fallback) {
            const source=await el.innerText();
            const privateCount=(source.match(/\p{Co}/gu)||[]).length;
            if(privateCount>=10 || (/\p{Script=Arabic}/u.test(source) && (privateCount>=2 || source.includes('\ufffd')))) {
              fallback='ترميز الحروف خاص';
            } else {
              try {
                await require('./ScribdCatcher.export.cjs').exportSheet(el,render,dir,n,mode);
                const check=spawnSync(process.env.PDF_PYTHON || 'python',[path.join(__dirname,'ScribdCatcher.check.py'),sheet,'1','--text'],{encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8'}});
                if(check.status!==0) fallback=check.status===42?'ترميز النص الناتج غير سليم':'فشل فحص الورقة المصدرة';
              } catch(error) {
                fallback='تعذر تحويل عناصر الصفحة: '+error.message.split('\n')[0];
              }
            }
          }
          if(fallback) await fs.rm(sheet,{force:true});
          const manifest = {width:0,height:0,pixelRatio,tiles:[]};
          let next=0;
          while(!manifest.tiles.length || next<manifest.height) {
            const clip=await el.evaluate(async (node,next)=>{
              const parent = (()=>{for(let a=node.parentElement;a;a=a.parentElement){
                if (/auto|scroll/.test(getComputedStyle(a).overflowY) && a.scrollHeight>a.clientHeight) return a;
              }return document.scrollingElement;})();
              const outer=parent===document.scrollingElement?{top:0,bottom:innerHeight}:parent.getBoundingClientRect();
              const top=Math.max(0,outer.top), bottom=Math.min(innerHeight,outer.bottom);
              const inset=Math.min(120,Math.floor((bottom-top)/4));
              const overlap=Math.min(80,inset);
              const target=Math.max(0,next-overlap);
              parent.scrollTo({top:parent.scrollTop+node.getBoundingClientRect().top+target-top-inset,behavior:'instant'});
              await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
              const r=node.getBoundingClientRect(), x=Math.ceil(r.left), w=Math.floor(r.width);
              if(x<0 || x+w>innerWidth) throw Error('عرض الصفحة أكبر من المساحة المرئية');
              const origin=Math.ceil(r.top);
              const height=Math.floor(r.bottom)-origin;
              let y=Math.ceil(Math.max(r.top,top)), end=Math.floor(Math.min(r.bottom,bottom));
              const visible=row=>[0.05,0.5,0.95].every(k=>node.contains(document.elementFromPoint(x+w*k,row)));
              while(y<end && !visible(y)) y++;
              while(end>y && !visible(end-1)) end--;
              if(end-y<1 || !visible(Math.floor((y+end)/2))) throw Error('جزء من الصفحة محجوب');
              return {x,y,width:w,height:end-y,offset:y-origin,pageHeight:height};
            },next);
            if(!manifest.tiles.length) {manifest.width=clip.width; manifest.height=clip.pageHeight;}
            if(clip.offset>next || clip.offset+clip.height<=next) throw Error('تعذر التقاط الصفحة '+n+' كاملة. الصف المتوقع '+next+'، والجزء المرئي من '+clip.offset+' إلى '+(clip.offset+clip.height)+' من ارتفاع '+manifest.height+' بكسل.');
            await el.evaluate(async node=>{
              await document.fonts.ready;
              await Promise.all([...node.querySelectorAll('img')].filter(img=>img.getClientRects().length).map(img=>img.decode()));
            },undefined,{timeout:12000});
            const {offset,pageHeight,...box}=clip;
            const file=n+'-'+manifest.tiles.length+'.png';
            await page.screenshot({path:path.join(dir,file),clip:box,scale:'device'});
            manifest.tiles.push({file,offset}); next=offset+clip.height;
          }
          await fs.writeFile(path.join(dir,n+'.json'),JSON.stringify(manifest));
          const verified=runAssembler(dir,'--page',n);
          if(verified.status!==0) throw Error(verified.stderr?.trim() || String(verified.error));
          if(render && !fallback) {
            const comparison=runAssembler(dir,'--compare',n);
            if(comparison.status===42) {
              fallback='اختلاف بصري عن صفحة العارض';
              await fs.rm(sheet,{force:true});
            } else if(comparison.status!==0) {
              throw Error(comparison.stderr?.trim() || 'تعذرت مقارنة شكل الصفحة');
            }
          }
          if(fallback) console.log('الصفحة '+n+' — '+fallback+'؛ حُفظت كصورة، والنص فيها غير قابل للنسخ.');
          break;
        } catch(error) {
          if(attempt===3) throw error;
          console.log('أعيد التقاط الصفحة '+n+' ('+(attempt+1)+'/3): '+error.message);
          await new Promise(resolve=>setTimeout(resolve,500*attempt));
        }
      }
      console.log(n+' / '+total);
    }
    const proc=runAssembler(dir,output,total);
    if(proc.status!==0) throw Error(proc.stderr || String(proc.error));
    return total;
  } finally {if(render) await render.close();await fs.rm(dir,{recursive:true,force:true});}
}
module.exports={captureVisible};
