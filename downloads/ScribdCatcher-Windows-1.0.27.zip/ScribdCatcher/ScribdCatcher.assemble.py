import json
import sys
from pathlib import Path
from PIL import Image, ImageChops
import pymupdf

def render_page(folder, n):
    spec = json.loads((folder / f'{n}.json').read_text())
    ratio = spec.get('pixelRatio', 1)
    sheet = Image.new('RGB', (round(spec['width'] * ratio), round(spec['height'] * ratio)))
    end = 0
    for part in spec['tiles']:
        start = round(part['offset'] * ratio)
        with Image.open(folder / part['file']) as src:
            tile = src.convert('RGB')
        if tile.width != sheet.width or not 0 <= start <= end:
            raise ValueError(f'فجوة في الصفحة {n}')
        overlap = end - start
        if overlap:
            diff = ImageChops.difference(sheet.crop((0,start,sheet.width,end)),
                                         tile.crop((0,0,tile.width,overlap)))
            changed = sum(diff.convert('L').histogram()[5:])
            if changed > max(2, tile.width * overlap // 10000):
                # A small area can repaint while scrolling. Join only across
                # a contiguous matching band, keeping the newer pixels below it.
                band = 12
                cut = None
                for y in sorted(range(overlap-band+1), key=lambda y: abs(y-(overlap-band)/2)):
                    strip = diff.crop((0, y, tile.width, y+band))
                    if sum(strip.convert('L').histogram()[5:]) <= 2:
                        cut = y + band//2
                        break
                if cut is not None:
                    start += cut
                    tile = tile.crop((0,cut,tile.width,tile.height))
                else:
                    raise ValueError(f'تغيرت الصورة أثناء التقاط الصفحة {n}')
        sheet.paste(tile, (0,start))
        end = start + tile.height
    if end < sheet.height:
        raise ValueError(f'أسفل الصفحة {n} ناقص')
    return sheet

def resembles(reference, candidate):
    # Compare local regions so a missing title is visible even on a large spread.
    if abs(reference.width / reference.height - candidate.width / candidate.height) > 0.012:
        return False
    size = (max(1, reference.width // 2), max(1, reference.height // 2))
    ref = reference.convert('RGB').resize(size, Image.Resampling.LANCZOS)
    copy = candidate.convert('RGB').resize(size, Image.Resampling.LANCZOS)
    channels = ImageChops.difference(ref, copy).split()
    diff = ImageChops.lighter(ImageChops.lighter(channels[0], channels[1]), channels[2])
    for y in range(2, size[1] - 2, 20):
        for x in range(2, size[0] - 2, 20):
            tile = diff.crop((x, y, min(x + 20, size[0]-2), min(y + 20, size[1]-2)))
            if sum(tile.histogram()[36:]) > max(16, tile.width * tile.height * 0.15):
                return False
    return True


def compare_sheet(folder, n):
    with Image.open(folder / f'page-{n}.png') as ref, pymupdf.open(folder / f'sheet-{n}.pdf') as doc:
        page = doc[0]
        scale = ref.width / page.rect.width
        pix = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)
        return resembles(ref, Image.frombytes('RGB', (pix.width, pix.height), pix.samples))


def assemble(folder, output, total):
    with pymupdf.open() as pdf:
        for n in range(1, total + 1):
            sheet = folder / f'sheet-{n}.pdf'
            if sheet.exists():
                with pymupdf.open(sheet) as part:
                    if len(part) != 1:
                        raise ValueError(f'عدد أوراق غير متوقع في الصفحة {n}')
                    pdf.insert_pdf(part)
                continue
            image_path = folder / f'page-{n}.png'
            spec = json.loads((folder / f'{n}.json').read_text())
            width, height = spec['width'], spec['height']
            page = pdf.new_page(width=width*.75, height=height*.75)
            page.insert_image(page.rect, filename=str(image_path))
        pdf.save(output, deflate=True)

if __name__ == '__main__':
    folder = Path(sys.argv[1])
    try:
        if sys.argv[2] == '--compare':
            sys.exit(0 if compare_sheet(folder, int(sys.argv[3])) else 42)
        elif sys.argv[2] == '--page':
            n = int(sys.argv[3])
            render_page(folder, n).save(folder / f'page-{n}.png')
        else:
            assemble(folder, sys.argv[2], int(sys.argv[3]))
    except (ValueError, OSError) as error:
        sys.exit(str(error))
