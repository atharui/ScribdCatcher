const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {randomUUID}=require('node:crypto');
const {chromium}=require('playwright-core');
const {discover,sameDocument}=require('./ScribdCatcher.embed.cjs');
const {captureVisible}=require('./ScribdCatcher.visible.cjs');

async function run(browser,raw,method,folder) {
  const url=new URL(raw);
  const doc=/^\/(document|doc|presentation|embeds)\/(\d+)(?:\/|$)/.exec(url.pathname);
  if(!['capture','print','svg'].includes(method) || !doc || !['www.scribd.com','scribd.com'].includes(url.host) || url.protocol!=='https:' || url.username || url.password)
    throw Error('أدخل رابط مستند أو عارض من Scribd واختر طريقة التصدير');
  const scale=Number(process.env.SCRIBDCATCHER_SCALE ?? 2);
  if(!Number.isSafeInteger(scale) || scale<1) throw Error('معامل الدقة يجب أن يكون عددًا صحيحًا موجبًا يمكن تمثيله');
  console.log('معامل دقة الالتقاط ×'+scale);
  const ctx=await browser.newContext({locale:'en-US',deviceScaleFactor:scale});
  const tmp=path.join(folder,'.'+randomUUID()+'.pdf');
  try {
    const page=await ctx.newPage();
    console.log('فتح المستند '+doc[2]);
    const res=await page.goto(url.href,{waitUntil:'domcontentloaded'});
    if(!res?.ok()) throw Error('تعذر فتح المستند');
    if(!sameDocument(page.url(),doc[2])) {
      console.log('البحث عن رابط التضمين');
      const target=await discover(page,doc[2]);
      if(!target) throw Error('تعذر العثور على عارض مطابق');
      await page.goto(target,{waitUntil:'domcontentloaded'});
    }
    if(!sameDocument(page.url(),doc[2])) throw Error('لم يفتح عارض المستند');
    console.log('بدأ التصدير بطريقة '+({capture:'الالتقاط المرئي',print:'طباعة كل ورقة',svg:'تحويل العناصر إلى SVG'})[method]);
    const count=await captureVisible(page,tmp,method);
    const check=require('node:child_process').spawnSync(process.env.PDF_PYTHON||'python',[path.join(__dirname,'ScribdCatcher.check.py'),tmp,String(count)],{encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8'}});
    if(check.status!==0) throw Error(check.stderr?.trim() || 'تعذر فحص الناتج');
    if (process.env.SC_SAMPLE === '3') {
      const render = require('node:child_process').spawnSync(process.env.PDF_PYTHON || 'python',
        [path.join(__dirname,'sample_pages.py'), tmp, folder], {encoding:'utf8'});
      if (render.status !== 0) throw Error(render.stderr || 'Preview rendering failed');
      return folder;
    }
    const slug=(url.pathname.split('/')[3]||'document').replace(/[^\p{L}\p{N}_-]/gu,'_').slice(0,60);
    const out=path.join(folder,slug+'-'+doc[2]+'-'+method+'-'+Date.now()+'.pdf');
    await fs.copyFile(tmp,out,require('node:fs').constants.COPYFILE_EXCL);
    console.log(check.stdout.trim()); return out;
  } finally {await ctx.close();await fs.rm(tmp,{force:true});}
}
module.exports={run};
if(require.main===module)(async()=>{
 const folder=process.argv[4] ? path.resolve(process.argv[4]) : path.join(os.homedir(),'Downloads','ScribdCatcher');
 await fs.mkdir(folder,{recursive:true});
 console.log('تشغيل محرك كروم لقراءة المستند');
 const b=await chromium.launch({channel:'chrome',headless:true});
 try {console.log('FILE '+await run(b,process.argv[2],process.argv[3],folder));}
 finally {await b.close();}
})().catch(e=>{console.error(String(e.message).split('\n')[0]);process.exitCode=1});
