﻿$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class DesktopDisplay {
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr value);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("shell32.dll", CharSet=CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);
}
'@
try { [void][DesktopDisplay]::SetThreadDpiAwarenessContext([IntPtr](-4)) }
catch { try { [void][DesktopDisplay]::SetProcessDPIAware() } catch {} }
try { [void][DesktopDisplay]::SetCurrentProcessExplicitAppUserModelID('ScribdCatcher.Desktop') } catch {}
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Windows.Forms,System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$appTitle = "ScribdCatcher v1.0.27"
$strings = @{
    ar = @{
        Link = 'رابط المستند أو العارض'
        Method = 'طريقة التصدير'
        Quality = 'دقة حفظ الصفحات المصوّرة — اختر مستوى أو اكتب معامل تكبير صحيحًا مثل 10'
        Destination = 'مجلد الحفظ'
        Browse = 'اختيار مجلد…'
        Start = 'بدء التصدير'
        Open = 'فتح مجلد الحفظ'
        Old = 'السجلات السابقة'
        Ready = 'جاهز'
        Events = 'سجل الأحداث'
        Hint = 'يُحفظ سجل كل عملية داخل مجلد Logs بجانب الملف الناتج.'
        About = 'حول'
        Purpose = 'تصدير صفحات المستند المعروضة في عارض Scribd وجمعها بالترتيب في ملف PDF واحد.'
        FolderPrompt = 'اختر مجلد حفظ ملفات PDF'
        LogFilter = 'سجلات التصدير (*.txt)'
        Disk = 'تعذر حفظ سجل الأحداث على القرص.'
        BadFactor = 'أدخل معامل تكبير صحيحًا يبدأ من 1'
        BadLink = 'أدخل رابط مستند أو عارض من Scribd'
        BadPath = 'اختر مسار حفظ كاملًا'
        Preparing = 'جاري تجهيز التصدير'
        StartError = 'تعذّر البدء'
        Pages = 'اكتملت {0} صفحة'
        Saved = 'تم حفظ الملف'
        Done = 'اكتمل التصدير'
        Failed = 'فشل التصدير.'
        Busy = 'التصدير جارٍ. يمكنك تصغير النافذة.'
        Methods = @('التقاط الصفحات المرئية', 'طباعة كل ورقة إلى PDF', 'تحويل العناصر إلى SVG ثم PDF')
        Descriptions = @('يصوّر كل صفحة كما تظهر في العارض ويجمع الصور بالترتيب في ملف PDF واحد. النص داخل الصورة.', 'يطبع كل صفحة على حدة مؤقتًا، ثم يدمج الصفحات بالترتيب في ملف PDF واحد. تُحفظ الصفحات ذات الترميز غير الموثوق كصور لحماية شكل الحروف.', 'يعيد رسم النصوص والصور المدعومة في كل صفحة، ثم يجمع الصفحات في ملف PDF واحد. تُحفظ الصفحات ذات الترميز غير الموثوق كصور.')
        Levels = @('1 — منخفضة', '2 — عادية', '3 — عالية', '4 — عالية جدًا', '6 — فائقة', '8 — فائقة جدًا')
    }
    en = @{
        Link = 'Document or viewer URL'
        Method = 'Export method'
        Quality = 'Capture resolution — select a preset or enter a whole-number scale, such as 10'
        Destination = 'Output folder'
        Browse = 'Browse…'
        Start = 'Start export'
        Open = 'Open output folder'
        Old = 'Previous logs'
        Ready = 'Ready'
        Events = 'Event log'
        Hint = 'Each export log is saved in the Logs folder beside the PDF.'
        About = 'About'
        Purpose = 'Export pages displayed in the Scribd viewer and combine them in order into one PDF.'
        FolderPrompt = 'Choose a folder for PDF files'
        LogFilter = 'Export logs (*.txt)'
        Disk = 'Could not save the log to disk.'
        BadFactor = 'Enter a whole-number scale of 1 or higher.'
        BadLink = 'Enter a Scribd document or viewer URL.'
        BadPath = 'Choose an absolute output path.'
        Preparing = 'Preparing export'
        StartError = 'Could not start'
        Pages = 'Completed {0} pages'
        Saved = 'File saved'
        Done = 'Export complete'
        Failed = 'Export failed.'
        Busy = 'Export in progress. You can minimize the window.'
        Methods = @('Capture visible pages', 'Print each page to PDF', 'Convert elements to SVG, then PDF')
        Descriptions = @('Capture each displayed page as an image and combine the images into one PDF.', 'Print pages individually and merge them in order. Pages with unreliable text encoding are saved as images.', 'Redraw supported text and images and combine the pages into one PDF. Pages with unreliable text encoding are saved as images.')
        Levels = @('1 — Low', '2 — Normal', '3 — High', '4 — Very high', '6 — Ultra', '8 — Maximum')
    }
}
$xamlPath = Join-Path $PSScriptRoot 'ScribdCatcher.xaml'
[xml]$markup = [IO.File]::ReadAllText($xamlPath)
$reader = New-Object Xml.XmlNodeReader $markup
try { $form = [Windows.Markup.XamlReader]::Load($reader) } finally { $reader.Close() }
foreach ($node in $markup.SelectNodes('//*[@Name]')) {
    Set-Variable -Name ($node.GetAttribute('Name')) -Value ($form.FindName($node.GetAttribute('Name')))
}
$baseUri = New-Object Uri($xamlPath)
$form.FontFamily = [Windows.Media.FontFamily]::new($baseUri,'./Fonts/#Janna LT, Segoe UI')
function ReadArtwork([string]$name) {
    $path = Join-Path (Join-Path $PSScriptRoot 'Assets') $name
    return [Windows.Media.Imaging.BitmapFrame]::Create([Uri]::new($path))
}
$brandImage.Source = ReadArtwork 'brand.png'
$iconPath = Join-Path $PSScriptRoot 'Assets/ScribdCatcher.ico'
$form.Icon = ReadArtwork 'ScribdCatcher.ico'
$windowIcon = [Drawing.Icon]::new($iconPath)
$fontPath = Join-Path $PSScriptRoot 'Fonts/JannaLT-Regular.ttf'
$privateFonts = [Drawing.Text.PrivateFontCollection]::new()
$privateFonts.AddFontFile($fontPath)
$dialogFont = [Drawing.Font]::new($privateFonts.Families[0],10,[Drawing.FontStyle]::Regular)
$buttonImages = @{about='about'; browse='browse'; start='start'; open='open'; old='old'}
foreach ($name in $buttonImages.Keys) {
    $form.FindName($name).Tag = ReadArtwork ($buttonImages[$name]+'.png')
}
$form.Title = $appTitle
$work = [Windows.SystemParameters]::WorkArea
$form.Width = [Math]::Min(920,$work.Width)
$form.Height = [Math]::Min(900,$work.Height)
$viewport.Add_ScrollChanged({
    if ($viewport.ViewportWidth -le 0) { return }
    $compact = $viewport.ViewportWidth -lt 530
    if ($compact) {
        [Windows.Controls.Grid]::SetRow($browse,1)
        [Windows.Controls.Grid]::SetColumn($browse,0)
        $browse.HorizontalAlignment='Left'
    } else {
        [Windows.Controls.Grid]::SetRow($browse,0)
        [Windows.Controls.Grid]::SetColumn($browse,1)
        $browse.HorizontalAlignment='Stretch'
    }
})
$method.Add_SelectionChanged({
    if (!$script:switchingLanguage -and $method.SelectedIndex -ge 0) {
        $methodHint.Text=$ui.Descriptions[$method.SelectedIndex]
    }
})
$interop = New-Object Windows.Interop.WindowInteropHelper $form
Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @'
public sealed class DialogOwner : System.Windows.Forms.IWin32Window {
    public System.IntPtr Handle { get; set; }
}
'@
$owner = New-Object DialogOwner
$form.Add_SourceInitialized({ $owner.Handle=$interop.Handle })
$location.Text = Join-Path $env:USERPROFILE 'Downloads\ScribdCatcher'
$settings = Join-Path $env:LOCALAPPDATA 'ScribdCatcher'
[void][IO.Directory]::CreateDirectory($settings)
# Import preferences once from the previous product directory.
$previousSettings = Join-Path $env:LOCALAPPDATA 'DocumentPDF'
foreach ($file in @('folder.txt','language.txt')) {
    $from=Join-Path $previousSettings $file
    $to=Join-Path $settings $file
    if ([IO.File]::Exists($from) -and ![IO.File]::Exists($to)) {
        try {
            $setting=[IO.File]::ReadAllText($from)
            if ($file -eq 'folder.txt' -and $setting -eq (Join-Path $env:USERPROFILE 'Downloads\DocumentPDF')) {
                $setting=$location.Text
            }
            [IO.File]::WriteAllText($to,$setting)
        } catch {}
    }
}
$pref = Join-Path $settings 'folder.txt'
if ([IO.File]::Exists($pref)) { $location.Text = [IO.File]::ReadAllText($pref) }
$script:job = $null
$script:logfile = $null
$langPref = Join-Path $settings 'language.txt'
$script:statusKey = 'Ready'
$script:statusArg = ''
function SetStatus($key,$value='') {
    $script:statusKey=$key
    $script:statusArg=$value
    $status.Text=($ui[$key] -f $value)
    if ($key -eq 'Failed') { $status.Text += ' ' + $value }
}
function SetLanguage($language) {
    $index = [Math]::Max(0,$method.SelectedIndex)
    $preset = $quality.SelectedIndex
    $custom = $quality.Text
    if ($preset -lt 0 -and !$custom) { $preset=1 }
    $script:ui=$strings[$language]
    $rtl = $language -eq 'ar'
    $script:switchingLanguage=$true
    try {
        $layout.FlowDirection = if ($rtl) {'RightToLeft'} else {'LeftToRight'}
        $shellLayout.FlowDirection=$layout.FlowDirection
        $languageButton.Content=if ($rtl) {'العربية'} else {'English'}
        $languageButton.Tag=if ($rtl) {ReadArtwork 'sa.png'} else {ReadArtwork 'gb.png'}
        $about.Content=$ui.About
        $preview.Content=if ($rtl) {'معاينة المستند المحدد'} else {'Preview selected document'}
        UpdatePauseButton
        $LinkLabel.Text=if ($rtl) {'روابط المستندات (كل رابط في سطر)'} else {'Document links (one per line)'}
        $MethodLabel.Text=$ui.Method
        $QualityLabel.Text=$ui.Quality
        $DestinationLabel.Text=$ui.Destination
        $EventsLabel.Text=$ui.Events
        $browse.Content=$ui.Browse
        $start.Content=$ui.Start
        $open.Content=$ui.Open
        $old.Content=$ui.Old
        $hint.Text=$ui.Hint
        $method.Items.Clear()
        foreach ($item in $ui.Methods) { [void]$method.Items.Add($item) }
        $method.SelectedIndex=$index
        $quality.Items.Clear()
        foreach ($item in $ui.Levels) { [void]$quality.Items.Add($item) }
        if ($preset -ge 0) {$quality.SelectedIndex=$preset} else {$quality.Text=$custom}
        SetStatus $script:statusKey $script:statusArg
        $methodHint.Text=$ui.Descriptions[$index]
    } finally {
        $script:switchingLanguage=$false
    }
    try {[IO.File]::WriteAllText($langPref,$language)} catch {}
}
function SwitchLanguage($language) {
    if ($script:switchingLanguage) {return}
    try {SetLanguage $language} catch {
        [void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,$appTitle)
    }
}
$languageMenu = New-Object Windows.Controls.ContextMenu
foreach ($option in @(@('ar','العربية','sa.png'),@('en','English','gb.png'))) {
    $item = New-Object Windows.Controls.MenuItem
    $item.Header=$option[1]
    $item.Tag=$option[0]
    $flag=New-Object Windows.Controls.Image
    $flag.Source=ReadArtwork $option[2]
    $flag.Width=18
    $item.Icon=$flag
    $item.Add_Click({param($sender,$e) SwitchLanguage $sender.Tag})
    [void]$languageMenu.Items.Add($item)
}
$languageButton.Add_Click({
    $languageMenu.PlacementTarget=$languageButton
    $languageMenu.Placement='Bottom'
    $languageMenu.IsOpen=$true
})
$about.Add_Click({
    $dialog = New-Object Windows.Forms.Form
    try {
        if (!('ScribdCatcher.WaterPanel' -as [type])) {
            Add-Type -Path (Join-Path $PSScriptRoot 'ScribdCatcher.About.cs') -ReferencedAssemblies 'System.dll','System.Drawing.dll','System.Windows.Forms.dll'
        }
        $dialog.Text=$ui.About
        $dialog.Font=$dialogFont
        $dialog.Icon=$windowIcon
        $dialog.StartPosition='CenterParent'
        $dialog.FormBorderStyle='FixedDialog'
        $dialog.MaximizeBox=$false
        $dialog.MinimizeBox=$false
        $area=[Windows.Forms.Screen]::FromHandle($owner.Handle).WorkingArea
        $dialog.ClientSize=[Drawing.Size]::new([Math]::Min(510,$area.Width-20),[Math]::Min(315,$area.Height-54))
        $dialog.AutoScaleMode='Dpi'
        $rtl = $layout.FlowDirection -eq 'RightToLeft'
        $rights = if ($rtl) { 'IG : RSOPD © 2026 كرم' } else { 'IG : RSOPD © 2026 Karam' }
        $closeText = if ($rtl) {'إغلاق'} else {'Close'}
        $water = New-Object -TypeName ScribdCatcher.WaterPanel -ArgumentList @($appTitle,$ui.Purpose,$rights,$closeText,$rtl,$dialogFont.FontFamily)
        $dialog.Controls.Add($water)
        $dialog.KeyPreview = $true
        $dialog.Add_KeyDown({param($sender,$e)
            if ($e.KeyCode -in @('Escape','Enter','Space')) {
                $e.SuppressKeyPress=$true
                $sender.Close()
            }
        })
        [void]$dialog.ShowDialog($owner)
    } catch {
        [void][Windows.Forms.MessageBox]::Show($owner,$_.Exception.Message,$appTitle)
    } finally {$dialog.Dispose()}
})
Add-Type -AssemblyName WindowsFormsIntegration
# A second launch of this version activates the existing main window.
$firstInstance=$false
$instanceGate=[Threading.Mutex]::new($false,'Local\ScribdCatcher.UI.23',[ref]$firstInstance)
$focusRequest=[Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::AutoReset,'Local\ScribdCatcher.Focus.23')
if (!$firstInstance) {
    [void]$focusRequest.Set()
    $focusRequest.Dispose()
    $instanceGate.Dispose()
    return
}
$navTimer=New-Object Windows.Threading.DispatcherTimer
$navTimer.Interval=[TimeSpan]::FromMilliseconds(600)
$navTimer.Add_Tick({
    if ($focusRequest.WaitOne(0)) {
        if ($form.WindowState -eq 'Minimized') {$form.WindowState='Normal'}
        [void]$form.Activate()
    }
})
$navTimer.Start()
$initialLanguage='ar' 
if ([IO.File]::Exists($langPref) -and [IO.File]::ReadAllText($langPref) -eq 'en') {$initialLanguage='en'}
function EventLine([string]$line,[bool]$errorLine=$false) {
    $entry = (Get-Date -Format 'HH:mm:ss') + '  ' + $line + [Environment]::NewLine
    $end=$events.Document.Blocks.LastBlock
    $run=[Windows.Documents.Run]::new($entry)
    if ($errorLine) { $run.Foreground=[Windows.Media.Brushes]::Firebrick }
    [void]$end.Inlines.Add($run)
    $events.ScrollToEnd()
    if ($script:logfile) {
        try { [IO.File]::AppendAllText($script:logfile,$entry) } catch { $script:logfile=$null; $events.AppendText($ui.Disk + [Environment]::NewLine) }
    }
}
$browse.Add_Click({
    $dialog = New-Object Windows.Forms.FolderBrowserDialog
    $dialog.Description = $ui.FolderPrompt
    if ([IO.Directory]::Exists($location.Text)) {$dialog.SelectedPath=$location.Text}
    try { if ($dialog.ShowDialog($owner) -eq 'OK') {$location.Text=$dialog.SelectedPath} } finally {$dialog.Dispose()}
})
$open.Add_Click({
    if ([IO.Directory]::Exists($location.Text)) { Invoke-Item -LiteralPath $location.Text }
})
$old.Add_Click({
    $dialog = New-Object Windows.Forms.OpenFileDialog
    $dialog.Filter = $ui.LogFilter+'|*.txt'
    $dialog.InitialDirectory = Join-Path $location.Text 'Logs'
    try {
        if ($dialog.ShowDialog($owner) -eq 'OK') {
            $viewer = New-Object Windows.Forms.Form
            $viewer.Icon = $windowIcon
            $viewer.Font = $dialogFont
            $viewer.Text = [IO.Path]::GetFileName($dialog.FileName)
            $viewer.Size = New-Object Drawing.Size(740,480)
            $box = New-Object Windows.Forms.RichTextBox
            $box.Dock='Fill'; $box.ReadOnly=$true; $box.RightToLeft=if ($layout.FlowDirection -eq 'RightToLeft') {'Yes'} else {'No'}
            $box.Text=[IO.File]::ReadAllText($dialog.FileName)
            $viewer.Controls.Add($box)
            try { [void]$viewer.ShowDialog($owner) } finally { $viewer.Dispose() }
        }
    } finally {$dialog.Dispose()}
})
$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval=[TimeSpan]::FromMilliseconds(120)
function ControlsEnabled([bool]$enabled) {
    foreach ($c in @($start,$preview,$documents,$browse,$location,$method,$quality,$url)) { $c.IsEnabled=$enabled }
}
function UpdatePauseButton {
    $ar=$layout.FlowDirection -eq 'RightToLeft'
    $pause.IsEnabled=($null -ne $script:job -and !$script:previewing)
    $pause.Content=if ($script:paused) {if ($ar) {'استئناف'} else {'Resume'}} else {if ($ar) {'إيقاف مؤقت'} else {'Pause'}}
}
$url.Add_TextChanged({
    $documents.Items.Clear()
    foreach ($value in ($url.Text -split '(?i)\s+|(?<=.)(?=https?://)')) {
        if ($value) {
            [void]$documents.Items.Add([pscustomobject]@{Link=$value;Label=('{0}. {1}' -f ($documents.Items.Count+1),[Uri]::UnescapeDataString($value))})
        }
    }
    if ($documents.Items.Count) {$documents.SelectedIndex=0}
})
function BeginBatch([bool]$sample) {
    if ($script:job) {return}
    try {
        $script:previewing=$sample
        $script:pending=[Collections.Queue]::new()
        $items=if ($sample) {$documents.SelectedItem} else {$documents.Items}
        foreach ($item in $items) {$script:pending.Enqueue($item)}
        if (!$script:pending.Count) {throw $ui.BadLink}
        $script:factor=if ($quality.SelectedIndex -ge 0 -and $quality.Text -eq $quality.SelectedItem) {($quality.Text -split ' ')[0]} else {$quality.Text.Trim()}
        if ($script:factor -notmatch '^[1-9][0-9]*$') {throw $ui.BadFactor}
        if (![IO.Path]::IsPathRooted($location.Text)) {throw $ui.BadPath}
        $script:folder=[IO.Path]::GetFullPath($location.Text)
        $logs=Join-Path $folder 'Logs'
        [void][IO.Directory]::CreateDirectory($logs)
        [IO.File]::WriteAllText($pref,$folder)
        $script:logfile=Join-Path $logs ('job-'+[guid]::NewGuid()+'.txt')
        $script:workDir=Join-Path ([IO.Path]::GetTempPath()) ([guid]::NewGuid().ToString())
        [void][IO.Directory]::CreateDirectory($workDir)
        $script:pauseFile=Join-Path $workDir 'paused'
        $script:paused=$false
        $script:failures=0
        $events.Document.Blocks.LastBlock.Inlines.Clear()
        ControlsEnabled $false
        StartNext
    } catch {SetStatus StartError; EventLine $_.Exception.Message $true}
}
function MarkRow($row,$result) {
    if (!$script:previewing) {
        $row.Label=('{0}. [{1}] {2}' -f ($documents.Items.IndexOf($row)+1),$result,[Uri]::UnescapeDataString($row.Link))
        $documents.Items.Refresh()
    }
}
function StartNext {
    while ($script:pending.Count) {
      try {
        $row=$script:pending.Dequeue()
        $script:activeRow=$row
        $documents.SelectedItem=$row
        $documents.ScrollIntoView($row)
        $progress.Value=0
        EventLine $row.Label
        $uri=[uri]$row.Link
        if (!$uri.IsAbsoluteUri -or $uri.Scheme -ne 'https' -or $uri.Host -notin @('www.scribd.com','scribd.com') -or $uri.AbsolutePath -notmatch '^/(document|doc|presentation|embeds)/\d+(/|$)') {throw $ui.BadLink}
        $info=New-Object Diagnostics.ProcessStartInfo
        $info.FileName=Join-Path $PSHOME 'powershell.exe'
        $info.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $PSScriptRoot 'ScribdCatcher.Worker.ps1')+'"'
        $info.WorkingDirectory=$PSScriptRoot
        $info.UseShellExecute=$false
        $info.CreateNoWindow=$true
        $info.RedirectStandardOutput=$true
        $info.RedirectStandardError=$true
        $info.StandardOutputEncoding=[Text.Encoding]::UTF8
        $info.StandardErrorEncoding=[Text.Encoding]::UTF8
        $info.EnvironmentVariables['SCRIBDCATCHER_SCALE']=$factor
        $info.EnvironmentVariables['SCRIBDCATCHER_URL']=$uri.AbsoluteUri
        $info.EnvironmentVariables['SCRIBDCATCHER_FOLDER']=if ($script:previewing) {$workDir} else {$folder}
        $info.EnvironmentVariables['SC_PAUSE_FILE']=$pauseFile
        if ($script:previewing) {$info.EnvironmentVariables['SC_SAMPLE']='3'}
        $info.EnvironmentVariables['SCRIBDCATCHER_METHOD']=@('capture','print','svg')[$method.SelectedIndex]
        EventLine ($ui.Method+': '+$method.Text)
        EventLine ($ui.Destination+': '+$folder)
        $script:job=[Diagnostics.Process]::Start($info)
        $script:streams=@(
            @{reader=$script:job.StandardOutput; task=$script:job.StandardOutput.ReadLineAsync(); err=$false},
            @{reader=$script:job.StandardError; task=$script:job.StandardError.ReadLineAsync(); err=$true}
        )
        $script:lastError=''
        $script:saved=$false
        UpdatePauseButton
        SetStatus Preparing
        $timer.Start()
        return
      } catch {$script:failures++; MarkRow $row $ui.Failed; EventLine $_.Exception.Message $true}
    }
    ControlsEnabled $true
    UpdatePauseButton
    if ($script:failures) {SetStatus Failed ([string]$script:failures)} else {SetStatus Done}
    Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
}
$start.Add_Click({BeginBatch $false})
$preview.Add_Click({BeginBatch $true})
$pause.Add_Click({
    if ($script:paused) {[IO.File]::Delete($pauseFile)} else {[IO.File]::WriteAllText($pauseFile,'')}
    $script:paused=!$script:paused
    UpdatePauseButton
})
function ShowSample {
    $window=New-Object Windows.Window
    $window.Owner=$form
    $window.Title=$preview.Content
    $window.Width=[Math]::Min(800,$work.Width)
    $window.Height=[Math]::Min(850,$work.Height)
    $window.WindowStartupLocation='CenterOwner'
    $scroll=New-Object Windows.Controls.ScrollViewer
    $stack=New-Object Windows.Controls.StackPanel
    foreach ($file in (Get-ChildItem -LiteralPath $workDir -Filter 'preview-*.png' | Sort-Object Name)) {
        $image=New-Object Windows.Controls.Image
        $image.Source=[Windows.Media.Imaging.BitmapFrame]::Create([Uri]::new($file.FullName),[Windows.Media.Imaging.BitmapCreateOptions]::None,[Windows.Media.Imaging.BitmapCacheOption]::OnLoad)
        $image.Margin='8'
        [void]$stack.Children.Add($image)
    }
    $scroll.Content=$stack
    $window.Content=$scroll
    [void]$window.ShowDialog()
}
$timer.Add_Tick({
    foreach($s in $script:streams) {
        while($s.task -and $s.task.IsCompleted) {
            $line=$s.task.GetAwaiter().GetResult()
            if($null -eq $line) {$s.task=$null; break}
            $s.task=$s.reader.ReadLineAsync()
            if($line -match '^(\d+) / (\d+)$') {
                $progress.Maximum=[int]$Matches[2]; $progress.Value=[int]$Matches[1]
                SetStatus Pages $line
            }
            if($line.StartsWith('FILE ')) {$line=$ui.Saved+': '+$line.Substring(5); $script:saved=$true}
            if($s.err) {$script:lastError=$line}
            EventLine $line ($s.err -and $line -notmatch '^(Checked |Using |Resolved |Installed )')
        }
    }
    if ($script:job.HasExited -and !$script:streams[0].task -and !$script:streams[1].task) {
        $timer.Stop()
        $ok=($script:job.ExitCode -eq 0 -and $script:saved)
        $script:job.Dispose(); $script:job=$null
        if ($ok) {MarkRow $activeRow $ui.Done} else {MarkRow $activeRow $ui.Failed}
        if (!$ok) {$script:failures++; SetStatus Failed $script:lastError; EventLine $status.Text $true}
        if ($ok -and $script:previewing) {try {ShowSample} catch {$script:failures++; EventLine $_.Exception.Message $true}}
        StartNext
    }
})
$form.Add_Closing({param($sender,$e)
    if ($script:job) {$e.Cancel=$true; SetStatus Busy}
})
SetLanguage $initialLanguage
try { [void]$form.ShowDialog() }
finally {
    $navTimer.Stop(); $focusRequest.Dispose(); $instanceGate.Dispose(); $timer.Stop(); $dialogFont.Dispose(); $privateFonts.Dispose(); $windowIcon.Dispose()
}