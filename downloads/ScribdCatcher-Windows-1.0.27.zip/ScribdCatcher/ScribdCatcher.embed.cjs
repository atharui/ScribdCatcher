function sameDocument(raw, id) {
  try {
    const u = new URL(raw);
    return u.protocol === 'https:' && /^(www\.)?scribd\.com$/.test(u.hostname)
      && !u.username && !u.password && !u.port && u.pathname.replace(/\/$/,'') === '/embeds/'+id+'/content';
  } catch { return false; }
}

async function links(page, markup = '') {
  return page.evaluate(markup => {
    const found = [...document.querySelectorAll('iframe[src], a[href], link[rel=alternate][href]')]
      .map(el => el.src || el.href);
    const snippets = [...document.querySelectorAll('textarea,input,pre,code')]
      .filter(el=>el.getClientRects().length).map(el=>el.value || el.textContent);
    for (const snippet of [markup,...snippets]) {
      const value = snippet.trim();
      if (!value) continue;
      if (/^https:\/\//i.test(value)) found.push(value);
      if (/<(?:iframe|a)\s/i.test(value)) {
        const template = document.createElement('template');
        template.innerHTML = value;
        for(const el of template.content.querySelectorAll('iframe[src],a[href]')) {
          try { found.push(new URL(el.getAttribute('src') || el.getAttribute('href'), location.href).href); } catch {}
        }
      }
    }
    return found;
  }, markup);
}

async function discover(page, id) {
  const match = url=>sameDocument(url,id);
  const published = (await links(page)).find(match);
  if (published) return published;
  const endpoint = await page.locator('link[type="application/json+oembed"][href]').first().getAttribute('href',{timeout:500}).catch(()=>null);
  const standard = new URL('https://www.scribd.com/services/oembed');
  standard.searchParams.set('url',page.url());
  standard.searchParams.set('format','json');
  for (const address of new Set([endpoint,standard.href].filter(Boolean))) {
    const u = new URL(address,page.url());
    if (u.protocol==='https:' && /^(www\.)?scribd\.com$/.test(u.host)) {
      const res=await page.request.get(u.href,{timeout:6000,maxRedirects:0}).catch(()=>null);
      if(res) {
        try {
          const data=res.ok()?await res.json().catch(()=>null):null;
          if(typeof data?.html==='string') {
            const target=(await links(page,data.html)).find(match);
            if(target) return target;
          }
        } finally {await res.dispose();}
      }
    }
  }
  const actions=page.getByRole('button',{name:/^(embed|تضمين)$/i})
    .or(page.getByRole('link',{name:/^(embed|تضمين)$/i})).first();
  if(!await actions.click({timeout:4000}).then(()=>true,()=>false)) return null;
  const deadline=Date.now()+6000;
  while(Date.now()<deadline) {
    for(const tab of page.context().pages()) {
      if(match(tab.url())) return tab.url();
      if(!/^https:\/\/(?:www\.)?scribd\.com\//i.test(tab.url())) continue;
      const target=(await links(tab).catch(()=>[])).find(match);
      if(target) return target;
    }
    await new Promise(resolve=>setTimeout(resolve,250));
  }
  return null;
}
module.exports={discover,sameDocument};
