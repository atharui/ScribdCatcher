"""Host the Qt queue inside the WPF tab's native panel (Windows only)."""
import ctypes
from ctypes import wintypes as W
import os
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QWindow

def owner_alive():
    api=ctypes.WinDLL('user32',use_last_error=True)
    api.GetWindowThreadProcessId.argtypes=[W.HWND,ctypes.POINTER(W.DWORD)]
    pid=W.DWORD()
    api.GetWindowThreadProcessId(int(os.environ['SC_QUEUE_PARENT']),ctypes.byref(pid))
    return pid.value==int(os.environ['SC_QUEUE_OWNER'])

class EmbeddedQueue:
    def __init__(self, widget):
        self.widget = widget
        self.parent_id = int(os.environ['SC_QUEUE_PARENT'])
        self.user32 = ctypes.WinDLL('user32', use_last_error=True)
        self.user32.GetClientRect.argtypes = [W.HWND, ctypes.POINTER(W.RECT)]
        self.user32.GetClientRect.restype = W.BOOL
        self.user32.IsWindow.argtypes = [W.HWND]
        self.user32.IsWindow.restype = W.BOOL
        self.user32.GetWindowThreadProcessId.argtypes = [W.HWND,ctypes.POINTER(W.DWORD)]
        self.user32.SetWindowPos.argtypes = [W.HWND,W.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,W.UINT]
        self.user32.SetWindowPos.restype = W.BOOL
        self.owner_pid = int(os.environ['SC_QUEUE_OWNER'])
        self.session = Path(os.environ['SC_QUEUE_SESSION'])
        self.last_size = None
        self.last_count = None
        self.host = QWindow.fromWinId(self.parent_id)
        if self.host is None: raise RuntimeError('Queue tab handle unavailable')
        widget.setWindowFlag(Qt.FramelessWindowHint)
        widget.setAttribute(Qt.WA_NativeWindow)
        self.hwnd = int(widget.winId())
        self.child = widget.windowHandle()
        self.child.setParent(self.host)
        self.child.setFlags(Qt.SubWindow | Qt.FramelessWindowHint)
        self.hwnd = int(widget.winId())
        self.user32.GetParent.argtypes=[W.HWND]
        self.user32.GetParent.restype=W.HWND
        self.user32.SetParent.argtypes=[W.HWND,W.HWND]
        self.user32.SetParent.restype=W.HWND
        self.user32.GetWindowLongW.argtypes=[W.HWND,ctypes.c_int]
        self.user32.SetWindowLongW.argtypes=[W.HWND,ctypes.c_int,W.LONG]
        style=self.user32.GetWindowLongW(self.hwnd,-16)
        self.user32.SetWindowLongW(self.hwnd,-16,(style & ~0x80000000) | 0x40000000)
        if self.user32.GetParent(self.hwnd)!=self.parent_id:
            self.user32.SetParent(self.hwnd,self.parent_id)
        if self.user32.GetParent(self.hwnd)!=self.parent_id:
            raise RuntimeError('Could not attach downloads to its tab')
        widget.show()
        self.timer = QTimer(widget)
        self.timer.timeout.connect(self.sync)
        self.timer.start(180)
        self.sync()

    def sync(self):
        rect=W.RECT(); pid=W.DWORD()
        self.user32.GetWindowThreadProcessId(self.parent_id,ctypes.byref(pid))
        if Path(str(self.session)+".close").exists() or pid.value!=self.owner_pid or not self.user32.GetClientRect(self.parent_id,ctypes.byref(rect)):
            self.timer.stop()
            self.widget.close()
            return
        size=(rect.right,rect.bottom)
        if min(size)>0 and size!=self.last_size:
            self.user32.SetWindowPos(self.hwnd,None,0,0,*size,0x14)
            self.last_size=size
        count=self.widget.db.execute("SELECT count(*), sum(state='done') FROM jobs").fetchone()
        status=f'{count[1] or 0}/{count[0]}'
        if status!=self.last_count:
            try:
                tmp=self.session.with_suffix('.tmp')
                tmp.write_text(status,encoding='ascii')
                tmp.replace(self.session)
                self.last_count=status
            except OSError: pass
        try:
            lang=(self.session.parent/'language.txt').read_text(encoding='utf-8-sig').strip()
        except OSError: return
        if lang in ('ar','en'): self.widget.set_language(lang)
