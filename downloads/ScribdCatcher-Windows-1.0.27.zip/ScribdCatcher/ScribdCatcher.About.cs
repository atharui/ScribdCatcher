using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ScribdCatcher {
    public sealed class WaterPanel : Panel {
        sealed class Wave { public Point Center; public long Start; }
        readonly List<Wave> waves = new List<Wave>();
        readonly Stopwatch clock = Stopwatch.StartNew();
        readonly Timer timer = new Timer();
        readonly string title, purpose, rights, closeText;
        readonly bool rtl;
        readonly FontFamily face;
        Bitmap frame;
        int[] original, pixels;
        long last = -100;

        public WaterPanel(string caption, string description, string copyright, string closeLabel, bool rightToLeft, FontFamily typeface) {
            face = typeface;
            title = caption;
            purpose = description;
            rights = copyright;
            closeText = closeLabel;
            rtl = rightToLeft;
            AccessibleName = caption + ". " + purpose + ". " + rights;
            AccessibleDescription = closeLabel + " (Esc)";
            DoubleBuffered = true;
            Dock = DockStyle.Fill;
            timer.Interval = 32;
            timer.Tick += delegate { Invalidate(); };
        }

        protected override void OnMouseMove(MouseEventArgs e) {
            base.OnMouseMove(e);
            if (clock.ElapsedMilliseconds - last < 65) return;
            last = clock.ElapsedMilliseconds;
            waves.Add(new Wave { Center = e.Location, Start = last });
            timer.Start();
            Invalidate();
        }

        Rectangle CloseBounds {
            get { return new Rectangle(Width*37/100, Height*80/100, Width*26/100, Height*13/100); }
        }

        protected override void OnMouseClick(MouseEventArgs e) {
            base.OnMouseClick(e);
            if (e.Button == MouseButtons.Left && CloseBounds.Contains(e.Location)) FindForm().Close();
        }

        void MakeSurface() {
            if (frame != null) frame.Dispose();
            frame = new Bitmap(Width, Height, PixelFormat.Format32bppArgb);
            using (Graphics g = Graphics.FromImage(frame))
            using (var fill = new LinearGradientBrush(ClientRectangle, Color.FromArgb(23,39,67), Color.FromArgb(55,87,138), 22f))
            using (var pen = new Pen(Color.FromArgb(38,213,249,241), 1.5f))
            using (var font = new Font(face, Height * .093f, FontStyle.Regular, GraphicsUnit.Pixel))
            using (var body = new Font(face, Height * .056f, GraphicsUnit.Pixel))
            using (var credit = new Font(face, Height * .06f, FontStyle.Regular, GraphicsUnit.Pixel))
            using (var border = new Pen(Color.FromArgb(175,255,255,255)))
            using (var align = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center }) {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.FillRectangle(fill, ClientRectangle);
                for (int y = -30; y < Height + 30; y += 11)
                    g.DrawBezier(pen, -10,y, Width/3,y+50, Width*2/3,y-50, Width+10,y);
                g.DrawString(title, font, Brushes.White, new RectangleF(0, Height*.07f, Width, Height*.23f), align);
                if (rtl) align.FormatFlags |= StringFormatFlags.DirectionRightToLeft;
                g.DrawString(purpose, body, Brushes.White, new RectangleF(Width*.06f, Height*.30f, Width*.88f, Height*.27f), align);
                align.FormatFlags &= ~StringFormatFlags.DirectionRightToLeft;
                g.DrawString(rights, credit, Brushes.White, new RectangleF(0, Height*.58f, Width, Height*.16f), align);
                if (rtl) align.FormatFlags |= StringFormatFlags.DirectionRightToLeft;
                g.DrawRectangle(border, CloseBounds);
                g.DrawString(closeText, body, Brushes.White, CloseBounds, align);
            }
            original = new int[Width * Height];
            pixels = new int[original.Length];
            var data = frame.LockBits(ClientRectangle, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try { Marshal.Copy(data.Scan0, original, 0, original.Length); }
            finally { frame.UnlockBits(data); }
        }

        protected override void OnPaint(PaintEventArgs e) {
            if (Width < 2 || Height < 2) return;
            if (frame == null || frame.Size != ClientSize) MakeSurface();
            int w = Width, h = Height;
            Array.Copy(original, pixels, original.Length);
            long now = clock.ElapsedMilliseconds;
            waves.RemoveAll(delegate(Wave wave) { return now - wave.Start > 900; });
            foreach (Wave wave in waves) {
                double age = (now-wave.Start)/900.0, radius = age*93;
                int reach = (int)radius+16, cx = wave.Center.X, cy = wave.Center.Y;
                for (int y=Math.Max(0,cy-reach); y<=Math.Min(h-1,cy+reach); y++)
                    for (int x=Math.Max(0,cx-reach); x<=Math.Min(w-1,cx+reach); x++) {
                        int dx=x-cx, dy=y-cy;
                        double dist=Math.Sqrt(dx*dx+dy*dy), edge=dist-radius;
                        if (Math.Abs(edge)>=15 || dist<1) continue;
                        double shift=6*(1-age)*(1-Math.Abs(edge)/15)*Math.Sin(edge*0.42);
                        int sx=Math.Max(0,Math.Min(w-1,x+(int)Math.Round(dx/dist*shift)));
                        int sy=Math.Max(0,Math.Min(h-1,y+(int)Math.Round(dy/dist*shift)));
                        pixels[y*w+x]=original[sy*w+sx];
                    }
            }
            if (waves.Count == 0) timer.Stop();
            var data=frame.LockBits(ClientRectangle,ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
            try { Marshal.Copy(pixels,0,data.Scan0,pixels.Length); }
            finally { frame.UnlockBits(data); }
            e.Graphics.DrawImageUnscaled(frame,0,0);
        }
        protected override void Dispose(bool disposing) {
            if (disposing) { timer.Dispose(); if (frame != null) frame.Dispose(); }
            base.Dispose(disposing);
        }
    }
}
