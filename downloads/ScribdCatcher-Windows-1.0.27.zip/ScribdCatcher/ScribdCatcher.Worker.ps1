﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
Set-Location -LiteralPath $PSScriptRoot
try {
    $node = (Get-Command node.exe -ErrorAction Stop).Source
    $uv = (Get-Command uv.exe -ErrorAction Stop).Source
    $env:PDF_PYTHON = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    Write-Output 'تجهيز أدوات التصدير'
    if (-not (Test-Path -LiteralPath $env:PDF_PYTHON)) {
        & $uv venv --python 3.12 .venv
        if ($LASTEXITCODE -ne 0) { throw 'تعذر إعداد Python' }
    }
    & $uv pip install --python $env:PDF_PYTHON 'PyMuPDF>=1.25,<2' 'Pillow>=10,<13'
    if ($LASTEXITCODE -ne 0) { throw 'تعذر تجهيز مكتبات PDF' }
    & $node (Join-Path $PSScriptRoot 'ScribdCatcher.job.cjs') $env:SCRIBDCATCHER_URL $env:SCRIBDCATCHER_METHOD $env:SCRIBDCATCHER_FOLDER
    exit $LASTEXITCODE
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
