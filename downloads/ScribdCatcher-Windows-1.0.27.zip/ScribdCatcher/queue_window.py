import os
import sys
import threading
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QLockFile, QUrl
from PySide6.QtGui import QIcon, QPixmap, QFontDatabase, QFont, QDesktopServices
from PySide6.QtWidgets import (QApplication,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QPlainTextEdit,QLineEdit,QComboBox,QFileDialog,QMessageBox,QTableWidget,QTableWidgetItem,
    QHeaderView,QAbstractItemView,QScrollArea,QSplitter)
from queue_core import pasted_links, repair_combined_rows, document_label, DOC_START, add, connect, update, run_job, pages_for

root = Path(__file__).resolve().parent
base = Path(os.environ['LOCALAPPDATA'])/'ScribdCatcher'/'Downloads'
base.mkdir(parents=True,exist_ok=True)
ar = os.environ.get('SC_QUEUE_LANG','ar')=='ar'
translations={}
def tr(a,e):
    translations[a]=translations[e]=(a,e)
    return a if ar else e
states = dict(ready=tr('بانتظار الدور','Queued'),running=tr('جارٍ التصدير','Exporting'),
              paused=tr('متوقف','Paused'),failed=tr('تعذّر','Failed'),done=tr('مكتمل','Completed'),
              attach=tr('بانتظار ملف PDF','Needs PDF'))


class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr('قائمة التحميل','Download queue')+' · ScribdCatcher')
        self.setWindowIcon(QIcon(str(root/'Assets/ScribdCatcher.ico')))
        self.db=connect(base)
        repair_combined_rows(self.db)
        with self.db:self.db.execute("UPDATE jobs SET state='paused' WHERE state='running'")
        self.pool=ThreadPoolExecutor(max_workers=1)
        self.future=None
        self.batch=False
        self.stop=threading.Event()
        self.active=None
        self.image=None
        self.natural=False
        self.close_pending=False
        self.orientation=None
        outer=QVBoxLayout(self)
        self.split=QSplitter(Qt.Horizontal)
        outer.addWidget(self.split)
        fields=QWidget(); left=QVBoxLayout(fields); self.split.addWidget(fields)
        self.input=QPlainTextEdit(); self.input.setMaximumHeight(78)
        self.input.setPlaceholderText(tr('الصق الروابط، كل رابط في سطر','Paste one link per line'))
        left.addWidget(self.input)
        self.note=QLabel();self.note.setWordWrap(True);left.addWidget(self.note)
        self.range=QLineEdit(); self.range.setPlaceholderText(tr('كل الصفحات أو 1-5, 12, 20-25','All pages or 1-5, 12, 20-25'))
        self.scale=QComboBox()
        self.scale.addItems([tr('PDF الأصلي','Original PDF'),'1×','2×','3×','4×'])
        settings=QHBoxLayout(); settings.addWidget(self.range);settings.addWidget(self.scale);left.addLayout(settings)
        self.folder=QLineEdit(os.environ.get('SC_QUEUE_FOLDER') or str(Path.home()/'Downloads'/'ScribdCatcher'))
        row=QHBoxLayout();row.addWidget(self.folder);left.addLayout(row)
        self.button(row,tr('مجلد الحفظ','Folder'),self.choose_folder)
        row=QHBoxLayout();left.addLayout(row)
        self.button(row,tr('إضافة الروابط','Add links'),self.add_links)
        self.button(row,tr('إضافة ملفات PDF','Add PDFs'),self.add_files)
        self.table=QTableWidget(0,5)
        self.table.setHorizontalHeaderLabels([tr('المستند','Document'),tr('الحالة','Status'),tr('الصفحات','Pages'),tr('الحجم','Size'),tr('وقت الحفظ','Saved')])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch)
        for i in range(1,5):self.table.horizontalHeader().setSectionResizeMode(i,QHeaderView.ResizeToContents)
        left.addWidget(self.table)
        row=QHBoxLayout();left.addLayout(row)
        self.button(row,tr('بدء القائمة','Start queue'),self.start)
        self.button(row,tr('إيقاف مؤقت','Pause'),self.pause)
        self.button(row,tr('تحويل / استئناف المحدد','Convert / resume selected'),self.resume)
        row=QHBoxLayout();left.addLayout(row)
        self.button(row,tr('فتح الرابط','Open link'),self.open_link)
        self.button(row,tr('ربط PDF','Attach PDF'),self.attach)
        self.button(row,tr('فتح الملف','Open file'),lambda:self.open_output(False))
        self.button(row,tr('إظهار في المجلد','Show in folder'),lambda:self.open_output(True))
        panel=QWidget(); right=QVBoxLayout(panel);self.split.addWidget(panel)
        self.caption=QLabel(tr('معاينة المستند','Document preview'));self.caption.setWordWrap(True);right.addWidget(self.caption)
        self.scroll=QScrollArea();self.scroll.setAlignment(Qt.AlignCenter)
        self.picture=QLabel();self.scroll.setWidget(self.picture);right.addWidget(self.scroll)
        row=QHBoxLayout();right.addLayout(row)
        self.button(row,tr('معاينة بالإعدادات','Preview settings'),self.preview)
        self.button(row,tr('الحجم الفعلي / ملاءمة','Actual size / fit'),self.zoom)
        self.web=None
        self.preview_layout=right
        self.preview_url=None
        self.split.setChildrenCollapsible(False)
        self.split.setSizes([640,400])
        self.table.itemSelectionChanged.connect(self.selection)
        self.refresh()
        if self.table.rowCount():self.table.setCurrentCell(0,0)
        self.tick=QTimer(self);self.tick.timeout.connect(self.poll);self.tick.start(350)
        area=QApplication.primaryScreen().availableGeometry()
        self.resize(min(1080,area.width()),min(680,area.height()))
    def set_language(self,lang):
        global ar
        rtl=lang=='ar'
        if rtl==ar:return
        ar=rtl
        def convert(value):
            pair=translations.get(value)
            return pair[0 if ar else 1] if pair else value
        QApplication.instance().setLayoutDirection(Qt.RightToLeft if ar else Qt.LeftToRight)
        for w in self.findChildren(QPushButton)+self.findChildren(QLabel):
            if w is not self.picture:w.setText(convert(w.text()))
        for w in (self.input,self.range):w.setPlaceholderText(convert(w.placeholderText()))
        self.scale.setItemText(0,convert(self.scale.itemText(0)))
        for i in range(self.table.columnCount()):
            item=self.table.horizontalHeaderItem(i)
            item.setText(convert(item.text()))
        for state,value in list(states.items()):states[state]=convert(value)
        self.refresh()

    def button(self,row,text,action):
        b=QPushButton(text);row.addWidget(b)
        def call():
            try: action()
            except Exception as err:self.note.setText(str(err))
        b.clicked.connect(call)
    def choose_folder(self):
        p=QFileDialog.getExistingDirectory(self,'',self.folder.text())
        if p:self.folder.setText(p)
    def selected(self):
        i=self.table.currentRow()
        if i<0 or self.table.item(i,0) is None:return None
        key=self.table.item(i,0).data(Qt.UserRole)
        return self.db.execute('SELECT * FROM jobs WHERE id=?',(key,)).fetchone()
    def refresh(self,select=None):
        old=self.selected()
        key=select or (old['id'] if old else None)
        rows=list(self.db.execute('SELECT * FROM jobs ORDER BY rowid'))
        self.table.blockSignals(True);self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            vals=[document_label(r['source']) if r['title']==r['source'] else r['title'],states[r['state']],f"{r['done']}/{r['goal']}" if r['goal'] else '—',
                  f"{r['size']/1048576:.2f} MB" if r['output'] else '',r['finished']]
            for j,s in enumerate(vals):
                it=QTableWidgetItem(s);it.setToolTip(r['error'] or r['source']);self.table.setItem(i,j,it)
                if not j:it.setData(Qt.UserRole,r['id'])
            if r['id']==key:self.table.setCurrentCell(i,0);self.table.selectRow(i)
        self.table.blockSignals(False)
    def selection(self):
        if self.web:
            self.web.hide()
        self.scroll.show()
        self.image=None; self.picture.clear();self.caption.setText(tr('معاينة المستند','Document preview'))
        r=self.selected()
        if r:
            self.range.setText(r['pages']);self.scale.setCurrentIndex(r['scale'])
            self.note.setText(r['error'] or (tr('افتح رابط Scribd ونزّل الملف ثم اختر «ربط PDF».','Open Scribd, download the PDF, then use Attach PDF.') if r['state']=='attach' else r['source']))
            if r['state']=='attach':
                self.scribd_preview(r)
    def scribd_preview(self,r):
        try:
            if self.web is None:
                self.web=QWebEngineView(self)
                self.preview_layout.insertWidget(1,self.web,1)
            match=DOC_START.match(r['source'])
            address=('https://www.scribd.com/embeds/'+match.group().rsplit('/',1)[-1]+'/content'
                     if match else r['source'])
            self.caption.setText(document_label(r['source']))
            self.scroll.hide()
            self.web.show()
            if self.preview_url!=address or not self.web.title():
                self.web.setUrl(QUrl(address))
            self.preview_url=address
        except ImportError as err:
            self.note.setText(tr('تعذّر تحميل مكوّن المعاينة: ','Preview component unavailable: ')+str(err))
    def enqueue(self,values):
        folder=Path(self.folder.text().strip())
        if not folder.is_absolute():raise ValueError(tr('اختر مجلد حفظ كاملًا','Choose an absolute output folder'))
        ids=[]
        with self.db:
            for v in dict.fromkeys(x.strip() for x in values if x.strip()):
                ids.append(add(self.db,v,folder,self.range.text(),self.scale.currentIndex()))
        if ids:
            self.refresh(ids[0]);self.selection()
        return ids
    def add_links(self):
        links=pasted_links(self.input.toPlainText())
        if not links:
            self.note.setText(tr('الصق رابطًا أولًا.','Paste a link first.'))
            return []
        ids=self.enqueue(links)
        if ids:
            self.input.clear()
            self.note.setText(tr('تمت إضافة','Added')+f' {len(ids)}. '+self.note.text())
        return ids
    def add_files(self): self.enqueue(QFileDialog.getOpenFileNames(self,'','','PDF (*.pdf)')[0])
    def target(self):
        if self.input.toPlainText().strip():
            self.add_links()
        r=self.selected()
        if not r and self.table.rowCount():
            self.table.setCurrentCell(0,0)
            r=self.selected()
        if not r:self.note.setText(tr('الصق الروابط أو أضف ملف PDF أولًا.','Paste links or add a PDF first.'))
        return r
    def open_link(self):
        r=self.target()
        if r and r['source'].startswith('https://'):
            if not QDesktopServices.openUrl(QUrl(r['source'])):
                raise RuntimeError(tr('تعذّر فتح المتصفح.','Could not open the browser.'))
    def attach(self):
        r=self.target()
        if r and r['state']=='attach':
            p=QFileDialog.getOpenFileName(self,'','','PDF (*.pdf)')[0]
            if p:
                update(self.db,r['id'],local=p,state='ready')
                self.refresh();self.selection()
                if not self.future:self.preview()
    def open_output(self,folder):
        r=self.target()
        if r and not r['output']:
            self.note.setText(tr('يتاح الملف بعد اكتمال التحويل.','The output is available after conversion.'))
        if r and r['output']:
            p=Path(r['output'])
            if not p.is_file():raise FileNotFoundError(p)
            if folder:subprocess.Popen(['explorer.exe','/select,',str(p)])
            else:QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))
    def launch(self,r,preview):
        self.active=r['id'];self.is_preview=preview;self.stop.clear()
        if not preview:self.note.setText(tr('جارٍ التحويل…','Converting…'))
        if not preview:update(self.db,self.active,state='running',error='')
        self.future=self.pool.submit(run_job,base,self.active,self.stop,preview)
    def preview(self):
        if self.future:
            self.note.setText(tr('العملية الحالية قيد التنفيذ.','An operation is already running.'))
            return
        r=self.target()
        if not r:return
        if r['state']=='attach':
            self.scribd_preview(r)
            return
        if r['state']!='done' and not r['done']:
            if r['total']:pages_for(self.range.text(),r['total'])
            update(self.db,r['id'],pages=self.range.text(),scale=self.scale.currentIndex())
        self.launch(r,True)
    def start(self):
        if not self.target():return
        self.batch=True
        if not self.future:self.next()
    def next(self):
        r=self.db.execute("SELECT * FROM jobs WHERE state='ready' ORDER BY rowid LIMIT 1").fetchone()
        if r:self.launch(r,False)
        else:
            self.batch=False
            needs=self.db.execute("SELECT count(*) FROM jobs WHERE state='attach'").fetchone()[0]
            if needs:
                self.note.setText(tr('بانتظار ملف PDF لعدد','Waiting for a PDF for')+f' {needs}. '+tr('اختر المستند ثم اضغط «ربط PDF».','Select the document, then click Attach PDF.'))
            else:self.note.setText(tr('لا توجد ملفات جاهزة في القائمة.','No queued files are ready.'))
    def pause(self):
        self.batch=False;self.stop.set()
    def resume(self):
        r=self.target()
        if not r:return
        if self.future:
            self.note.setText(tr('انتظر انتهاء العملية الحالية.','Wait for the current operation to finish.'))
            return
        if r['state']=='attach':
            filename=QFileDialog.getOpenFileName(self,tr('اختر نسخة PDF الخاصة بهذا المستند','Choose the PDF for this document'),'','PDF (*.pdf)')[0]
            if not filename:
                self.note.setText(tr('لم يتم اختيار ملف للتحويل.','No file selected for conversion.'))
                return
            update(self.db,r['id'],local=filename,state='ready')
            r=self.selected()
        if r['state']=='done':
            self.open_output(False)
            return
        if r['state'] in ('failed','paused','ready'):
            if not r['done']:update(self.db,r['id'],pages=self.range.text(),scale=self.scale.currentIndex())
            self.batch=False
            self.launch(r,False)
    def zoom(self):self.natural=not self.natural;self.draw()
    def draw(self):
        if self.image:
            p=self.image if self.natural else self.image.scaled(self.scroll.viewport().size(),Qt.KeepAspectRatio,Qt.SmoothTransformation)
            self.picture.setPixmap(p);self.picture.resize(p.size())
    def resizeEvent(self,event):
        super().resizeEvent(event)
        orient=Qt.Vertical if self.width()<760 else Qt.Horizontal
        if self.split.orientation()!=orient:self.split.setOrientation(orient)
        QTimer.singleShot(0,self.draw)
    def poll(self):
        if not self.future:return
        if not self.future.done():
            if not self.is_preview:self.refresh()
            return
        try:
            value=self.future.result()
            if value:
                r=self.selected()
                if r and r['id']==self.active:
                    title,count,n,data=value;self.image=QPixmap();self.image.loadFromData(data)
                    self.caption.setText(f'{title} · {n}/{count}');self.draw()
        except InterruptedError:
            if not self.is_preview:update(self.db,self.active,state='paused')
        except Exception as e:
            self.note.setText(str(e))
            if not self.is_preview:update(self.db,self.active,state='failed',error=str(e))
        self.future=None;self.refresh()
        if self.close_pending:self.close()
        elif self.batch:self.next()
    def closeEvent(self,event):
        if self.future:
            self.close_pending=True;self.pause();event.ignore()
        else:
            self.tick.stop()
            self.pool.shutdown();self.db.close();event.accept()
            if os.environ.get('SC_QUEUE_PARENT'):
                QApplication.instance().quit()


from PySide6.QtWebEngineWidgets import QWebEngineView
QApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
app=QApplication(sys.argv)
lock=QLockFile(str(base/'queue.lock'));lock.setStaleLockTime(0)
# Wait before creating Window: its startup recovery must only run under the lock.
session=Path(os.environ['SC_QUEUE_SESSION']) if os.environ.get('SC_QUEUE_SESSION') else None
def write_status(text):
    if session:
        staging=session.with_suffix('.waiting')
        staging.write_text(text,encoding='ascii')
        staging.replace(session)

app.setLayoutDirection(Qt.RightToLeft if ar else Qt.LeftToRight)
font=QFontDatabase.addApplicationFont(str(root/'Fonts/JannaLT-Regular.ttf'))
if font>=0:app.setFont(QFont(QFontDatabase.applicationFontFamilies(font)[0],10))
def acquire():
    global window, embedded
    if session:
        from queue_embed import owner_alive
        if Path(str(session)+".close").exists() or not owner_alive():
            app.quit()
            return
    if not lock.tryLock(0):
        if lock.error()!=QLockFile.LockFailedError:
            raise OSError('Cannot access the queue lock: '+str(base))
        write_status('waiting')
        return
    retry.stop()
    window=Window()
    if session:
        from queue_embed import EmbeddedQueue
        embedded=EmbeddedQueue(window)
    else:
        window.show()

def attempt():
    try:
        acquire()
    except Exception:
        import traceback
        traceback.print_exc()
        app.exit(1)

retry=QTimer()
retry.setInterval(750)
retry.timeout.connect(attempt)
retry.start()
QTimer.singleShot(0,attempt)
try:
    result=app.exec()
finally:
    retry.stop()
    if lock.isLocked():lock.unlock()
sys.exit(result)
