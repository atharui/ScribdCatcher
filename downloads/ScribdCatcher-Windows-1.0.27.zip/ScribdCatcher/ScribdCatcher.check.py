import sys
import unicodedata
from pathlib import Path
import pymupdf

def unreliable_text(text):
    private = sum(unicodedata.category(ch) == 'Co' for ch in text)
    arabic = any('ARABIC LETTER' in unicodedata.name(ch, '') for ch in text)
    # A single private-use icon beside an otherwise healthy paragraph is common.
    return (private >= 2 and arabic) or private >= 10 or (arabic and '\ufffd' in text)


def verify(filename, expected, check_text=False):
    with pymupdf.open(filename) as doc:
        if not doc.is_pdf or doc.needs_pass or not len(doc):
            raise ValueError("الملف غير قابل للفحص كملف PDF مفتوح")
        if expected and expected != len(doc):
            raise ValueError(f"العدد المتوقع {expected} والمستلم {len(doc)}")
        blank = []
        for page in doc:
            if check_text and unreliable_text(page.get_text()):
                sys.exit(42)
            scale = min(1.5, 950 / max(page.rect.width, page.rect.height))
            pix = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)
            ratio, _ = pix.color_topusage()
            if ratio > 0.99995:
                blank.append(str(page.number + 1))
        if blank:
            raise ValueError("صفحات تبدو فارغة وتحتاج مراجعة: " + ", ".join(blank))
        print(f"تم فحص {len(doc)} صفحة")

if __name__ == "__main__":
    try:
        verify(Path(sys.argv[1]), int(sys.argv[2]), "--text" in sys.argv[3:])
    except Exception as exc:
        sys.exit(str(exc))
